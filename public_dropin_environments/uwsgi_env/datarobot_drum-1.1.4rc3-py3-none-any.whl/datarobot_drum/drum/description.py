version = "1.1.4rc3"
__version__ = version
project_name = "datarobot-drum"
